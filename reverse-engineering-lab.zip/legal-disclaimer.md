Legal Disclaimer

This repository is intended for educational purposes only. The simulated malware scripts and challenges mimic malicious behavior without causing harm.
Use responsibly in controlled environments.
